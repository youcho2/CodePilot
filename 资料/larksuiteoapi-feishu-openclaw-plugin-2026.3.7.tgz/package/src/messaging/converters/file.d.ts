/**
 * Copyright (c) 2026 ByteDance Ltd. and/or its affiliates
 * SPDX-License-Identifier: MIT
 *
 * Converter for "file" message type.
 */
import type { ContentConverterFn } from "./types.js";
export declare const convertFile: ContentConverterFn;
//# sourceMappingURL=file.d.ts.map