/**
 * Copyright (c) 2026 ByteDance Ltd. and/or its affiliates
 * SPDX-License-Identifier: MIT
 *
 * Agent dispatch for inbound Feishu messages.
 *
 * Builds the agent envelope, prepends chat history context, and
 * dispatches through the appropriate reply path (system command
 * vs. normal streaming/static flow).
 */
import type { ClawdbotConfig, RuntimeEnv, HistoryEntry } from "openclaw/plugin-sdk";
import type { MessageContext } from "../types.js";
import type { LarkAccount } from "../../core/types.js";
import type { FeishuGroupConfig } from "../../core/types.js";
import type { PermissionError } from "./permission.js";
export declare function dispatchToAgent(params: {
    ctx: MessageContext;
    permissionError?: PermissionError;
    mediaPayload: Record<string, unknown>;
    quotedContent?: string;
    account: LarkAccount;
    cfg: ClawdbotConfig;
    runtime?: RuntimeEnv;
    chatHistories?: Map<string, HistoryEntry[]>;
    historyLimit: number;
    /** Override the message ID used for reply threading.  When set, the
     *  reply-dispatcher uses this ID for typing indicators and card replies
     *  instead of ctx.messageId (which may be a synthetic ID). */
    replyToMessageId?: string;
    /** When set, controls whether the sender is authorized to execute
     *  control commands.  Computed by the handler via the SDK's access
     *  group command gating system. */
    commandAuthorized?: boolean;
    /** Per-group configuration for skills, systemPrompt, etc. */
    groupConfig?: FeishuGroupConfig;
    /** Default group configuration from the "*" wildcard entry. */
    defaultGroupConfig?: FeishuGroupConfig;
    /** When true, the reply dispatcher skips typing indicators. */
    skipTyping?: boolean;
}): Promise<void>;
//# sourceMappingURL=dispatch.d.ts.map